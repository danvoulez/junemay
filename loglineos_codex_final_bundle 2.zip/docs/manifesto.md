# Manifesto LogLineOS Genoma

Sistema simbólico 100% auditável.
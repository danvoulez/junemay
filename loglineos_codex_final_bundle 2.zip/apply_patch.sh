#!/bin/sh
# Script para aplicar todos os arquivos deste diretório em um repositório Git
# Recomendado: clone um repositório limpo antes de rodar isso

echo "Aplicando conteúdo como patch..."
cp -r * ../  # ou ajuste o destino conforme necessário
echo "Feito. Agora você pode revisar com git diff e commitar normalmente."
